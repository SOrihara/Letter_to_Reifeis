

rm(list=ls())

library(geex)
library(sandwich)
# library(PSweight)

set.seed(20240320)


ps <- function(xx) (1+exp(-xx))^(-1)

nn <- 1000
KK <- 1000


kekka_att_est <- kekka_ato_est <- matrix(0,ncol=4,nrow=KK)
kekka_att_ext <- kekka_ato_ext <- matrix(0,ncol=3,nrow=KK)



ll.flg=1; ll.flg2=1

for(kk in 1:KK){
  
  # set.seed(20240319)
  # nn <- 1000000
  
  ## Data generating mechanism
  ### Confounders
  if(ll.flg==1&ll.flg2==1){
    LL <- rbinom(nn,1,0.5)
    alpha <- c(-1,-2); beta <- c(-1,-1.5,1.5)
    mu1_att <- -1.001; mu0_att <- -0.222
    mu1_ato <- -1.001; mu0_ato <- -0.280
  }else if(ll.flg==2&ll.flg2==1){
    LL <- rbinom(nn,1,0.3)
    alpha <- c(1,0.1); beta <- c(1,1.5,0.5)
    mu1_att <- 1.613; mu0_att <- 0.460
    mu1_ato <- 1.582; mu0_ato <- 0.435
  }else if(ll.flg==3&ll.flg2==1){
    LL <- rnorm(nn)
    alpha <- c(1,0.1); beta <- c(1,0.5,-1.5)
    mu1_att <- 0.975; mu0_att <- 0.013
    mu1_ato <- 1.047; mu0_ato <- -0.024
  }else if(ll.flg==4&ll.flg2==1){
    LL <- rnorm(nn,mean=1)
    alpha <- c(1,-1); beta <- c(1,-1.5,-0.5)
    mu1_att <- -0.175; mu0_att <- -0.882
    mu1_ato <- -1.002; mu0_ato <- -1.498
  }else if(ll.flg==1&ll.flg2==2){
    LL <- rbinom(nn,1,0.5)
    alpha <- c(-1,-2); beta <- c(-1,-1.5,0)
    mu1_att <- -1.225; mu0_att <- -0.225
    mu1_ato <- -1.281; mu0_ato <- -0.281
  }else if(ll.flg==2&ll.flg2==2){
    LL <- rbinom(nn,1,0.3)
    alpha <- c(1,0.1); beta <- c(1,1.5,0)
    mu1_att <- 1.457; mu0_att <- 0.457
    mu1_ato <- 1.435; mu0_ato <- 0.435
  }else if(ll.flg==3&ll.flg2==2){
    LL <- rnorm(nn)
    alpha <- c(1,0.1); beta <- c(1,0.5,0)
    mu1_att <- 1.013; mu0_att <- 0.013
    mu1_ato <- 0.976; mu0_ato <- -0.020
  }else if(ll.flg==4&ll.flg2==2){
    LL <- rnorm(nn,mean=1)
    alpha <- c(1,-1); beta <- c(1,-1.5,0)
    mu1_att <- 0.117; mu0_att <- -0.883
    mu1_ato <- -0.503; mu0_ato <- -1.498
  }
  
  XX <- cbind(1,LL)
  
  ### Exposure
  AA_ln <- cbind(1,LL)%*%alpha
  AA <- mapply(rbinom,1,1,ps(AA_ln))
  # mean(AA)
  
  ps_t <- c(ps(AA_ln))
  
  # hist(ps_t[AA==1], col="red")
  # hist(ps_t[AA==0], col="blue")
  
  
  ### Outcome
  ee <- rnorm(nn,sd=0.5)
  YY0_ln <- cbind(0,LL,0)%*%beta
  # YY0 <- mapply(rbinom,1,1,ps(YY0_ln))
  YY0 <- c(YY0_ln)+ee

  YY1_ln <- cbind(1,LL,LL)%*%beta
  # YY1 <- mapply(rbinom,1,1,ps(YY1_ln))
  YY1 <- c(YY1_ln)+ee
  
  YY <- c(AA*YY1+(1-AA)*YY0)
  
  # mean(YY1[AA==1]); mean(YY0[AA==1])
  # mean(AA*(1-ps_t)*YY)/mean(AA*(1-ps_t)); mean((1-AA)*ps_t*YY)/mean((1-AA)*ps_t)
  # mean(ps_t*(1-ps_t)*(YY1-YY0))/mean(ps_t*(1-ps_t))
  
  
  DD <- data.frame(cbind(LL,AA,YY))
  names(DD) <- c("LL","AA","YY")
  
  
  
  ##Estimation
  psmod <- glm(AA~LL,family=binomial,data=DD)
  ps_est <- psmod$fit
  
  ww_att_est <- DD$AA+(1-DD$AA)*ps_est/(1-ps_est)  ##ATT est.
  ww_ato_est <- DD$AA*(1-ps_est)+(1-DD$AA)*ps_est  ##ATO est.
  
  tau_att_est <- lm(YY~AA,weight=ww_att_est,data=DD)
  tau_ato_est <- lm(YY~AA,weight=ww_ato_est,data=DD)
  
  ATT <- tau_att_est[[1]][2]
  mu0hat_att <- tau_att_est[[1]][1]
  mu1hat_att <- ATT+mu0hat_att
  
  ATO <- tau_ato_est[[1]][2]
  mu0hat_ato <- tau_ato_est[[1]][1]
  mu1hat_ato <- ATO+mu0hat_ato
  
  
  kekka_att_est[kk,] <- c(ATT,ATT+qnorm(0.025)*sqrt(sandwich(tau_att_est)[2,2]),ATT+qnorm(0.975)*sqrt(sandwich(tau_att_est)[2,2]),sqrt(sandwich(tau_att_est)[2,2]))
  kekka_ato_est[kk,] <- c(ATO,ATO+qnorm(0.025)*sqrt(sandwich(tau_ato_est)[2,2]),ATO+qnorm(0.975)*sqrt(sandwich(tau_ato_est)[2,2]),sqrt(sandwich(tau_ato_est)[2,2]))
  
  
  estfun_att <- function(data,model){
    LL <- model.matrix(model, data=data)
    AA <- model.response(model.frame(model, data=data))
    YY <- data$YY
    
    function(theta){
      p <- length(theta)
      p1 <- length(coef(model))
      lp <- LL%*%theta[1:p1]
      rho <- plogis(lp)
      IPW <- ifelse(AA == 1,1,exp(lp))
      
      score_eqns <- apply(LL,2,function(x) sum((AA-rho)*x))
      ce1 <- IPW*(AA==1)*(YY-theta[p-1])
      ce0 <- IPW*(AA==0)*(YY-theta[p])
      
      c(score_eqns,ce1,ce0)
    }
  }
  
  estfun_ato <- function(data,model){
    LL <- model.matrix(model, data=data)
    AA <- model.response(model.frame(model, data=data))
    YY <- data$YY
    
    function(theta){
      p <- length(theta)
      p1 <- length(coef(model))
      lp <- LL%*%theta[1:p1]
      rho <- plogis(lp)
      IPW <- ifelse(AA == 1,1-rho,rho)
      
      score_eqns <- apply(LL,2,function(x) sum((AA-rho)*x))
      ce1 <- IPW*(AA==1)*(YY-theta[p-1])
      ce0 <- IPW*(AA==0)*(YY-theta[p])
      
      c(score_eqns,ce1,ce0)
    }
  }
  
  
  results_att <- m_estimate(estFUN=estfun_att,
                            data=DD,
                            roots = c(coef(psmod),mu1hat_att,mu0hat_att),
                            compute_roots = F,
                            outer_args = list(model = psmod)
  )
  
  results_ato <- m_estimate(estFUN=estfun_ato,
                            data=DD,
                            roots = c(coef(psmod),mu1hat_ato,mu0hat_ato),
                            compute_roots = F,
                            outer_args = list(model = psmod)
  )
  
  
  se_att <- sqrt(c(1,-1)%*%vcov(results_att)[3:4, 3:4]%*%c(1,-1))
  kekka_att_ext[kk,] <- c(ATT+qnorm(0.025)*se_att, ATT+qnorm(0.975)*se_att, se_att)
  
  se_ato <- sqrt(c(1,-1)%*%vcov(results_ato)[3:4, 3:4]%*%c(1,-1))
  kekka_ato_ext[kk,] <- c(ATO+qnorm(0.025)*se_ato, ATO+qnorm(0.975)*se_ato, se_ato)
  
  
  if(kk%%100==0) print(kk)
}


kk_mat <- cbind(kekka_att_est,kekka_att_ext,kekka_ato_est,kekka_ato_ext)


# att <- ato <- 1
att <- -0.775; ato <- -0.721
# att <- 1.153; ato <- 1.144
# att <- 0.958; ato <- 1.067
# att <- 0.707; ato <- 0.500


kekka <- kk_mat[,c(1,8)]

apply(kekka,2,mean)
apply(kekka,2,sd)

apply(kk_mat[,c(7,4,14,11)],2,mean)


kekka_CI <- kk_mat[,c(2,3,5,6,9,10,12,13)]

mean(kekka_CI[,4]>att&kekka_CI[,3]<att)
mean(kekka_CI[,2]>att&kekka_CI[,1]<att)
mean(kekka_CI[,8]>ato&kekka_CI[,7]<ato)
mean(kekka_CI[,6]>ato&kekka_CI[,5]<ato)



